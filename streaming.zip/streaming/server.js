   var express = require('express'),
   app = express(),
   http = require('http'),
   socketIO = require('socket.io'),
   fs = require('fs'),
   path = require('path'),
   server, io, sockets = [], users = {};
   app.use(express.static(__dirname));
   app.get('/', function (req, res) {
      res.sendFile(__dirname + '/index.html');
   });

   var PORT = process.env.PORT || 5000;
   server = http.Server(app);
   server.listen(PORT);
   console.log('Listening on port ',PORT);
   io = socketIO(server);
   io.on('connection', function (socket) 
   {
      socket.on('add-user',function(data){
         users[data.userId] = {username: data.username, socketId: socket.id};
        console.log(users);
        /* socket.emit('add-users', {
            users: users,
         });*/
         socket.broadcast.emit('add-users', {
            users: users,
         });
      });
      
      console.log("connected: ", socket.id);
      
     socket.emit('add-users', {
         users: users
      });
      socket.on('make-offer', function (data) {
         socket.to(data.to).emit('offer-made', {
            offer: data.offer,
            socket: socket.id
         });
      });
    
      
      socket.on('send-me-stream',function(data){
         console.log(data);
         console.log(socket.id);
         socket.to(data.to).emit('send-stream', {
            socket: socket.id            
         });
      });

      socket.on('send-stream',function(data){
         console.log('send-stream',data);
 
      });

      socket.on('make-answer', function (data) {
         socket.to(data.to).emit('answer-made', {
            socket: socket.id,
            answer: data.answer
         });
      });
      socket.on('disconnect', function () {
         sockets.splice(sockets.indexOf(socket.id), 1);
         console.log("disconnected: ", users);

         for(var i in users) {
            if(users[i].socketId == socket.id) {
                delete users[i];
            }
         }

         console.log(" after disconnected: ", users);

         
         io.emit('remove-user', socket.id);
         });
         sockets.push(socket.id);
   });