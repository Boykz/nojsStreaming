var socket = io.connect('https://streamingkz.herokuapp.com'); //http://localhost:5000
var answersFrom = {}, offer;
var peerConnection = window.RTCPeerConnection ||  window.mozRTCPeerConnection || window.webkitRTCPeerConnection || window.msRTCPeerConnection;
var sessionDescription = window.RTCSessionDescription || window.mozRTCSessionDescription || window.webkitRTCSessionDescription || window.msRTCSessionDescription;
navigator.getUserMedia = (navigator.getUserMedia ||  navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia);
/*var pc = new peerConnection({ iceServers: [{ url: "stun:stun.services.mozilla.com",
username: "somename",
credential: "somecredentials" }]
});*/
var pc = new peerConnection({ iceServers: [{url:'stun:stun01.sipphone.com'},
{url:'stun:stun.ekiga.net'},
{url:'stun:stun.fwdnet.net'},
{url:'stun:stun.ideasip.com'},
{url:'stun:stun.iptel.org'},
{url:'stun:stun.rixtelecom.se'},
{url:'stun:stun.schlund.de'},
{url:'stun:stun.l.google.com:19302'},
{url:'stun:stun1.l.google.com:19302'},
{url:'stun:stun2.l.google.com:19302'},
{url:'stun:stun3.l.google.com:19302'},
{url:'stun:stun4.l.google.com:19302'},
{url:'stun:stunserver.org'},
{url:'stun:stun.softjoys.com'},
{url:'stun:stun.voiparound.com'},
{url:'stun:stun.voipbuster.com'},
{url:'stun:stun.voipstunt.com'},
{url:'stun:stun.voxgratia.org'},
{url:'stun:stun.xten.com'},
{
	url: 'turn:numb.viagenie.ca',
	credential: 'muazkh',
	username: 'webrtc@live.com'
},
{
	url: 'turn:192.158.29.39:3478?transport=udp',
	credential: 'JZEOEt2V3Qb0y27GRntt2u2PAYA=',
	username: '28224511:1379330808'
},
{
	url: 'turn:192.158.29.39:3478?transport=tcp',
	credential: 'JZEOEt2V3Qb0y27GRntt2u2PAYA=',
	username: '28224511:1379330808'
}]
});
pc.onaddstream = function (obj) {
    var col = document.createElement('div');
    col.setAttribute('class', 'col-lg-6');
    var vid = document.createElement('video');
    vid.setAttribute('class', 'video-small');
    vid.setAttribute('autoplay', 'autoplay');
    vid.setAttribute('id', 'video-small');
    col.appendChild(vid);
    document.getElementById('users-container').appendChild(col);
    vid.srcObject = obj.stream;// window.URL.createObjectURL(obj.stream);
 
} 

function error (err) {
    console.log('Error', err);
}

function createOffer (id) {
            socket.emit('send-me-stream', {           
            to: id
            });
}
socket.on('answer-made', function (data) {
    pc.setRemoteDescription(new sessionDescription(data.answer),function () {
        document.getElementById(data.socket).setAttribute('class', 'active');
        if (!answersFrom[data.socket]) {
            createOffer(data.socket);
            answersFrom[data.socket] = true;
        }
    }, error);
});
socket.on('offer-made', function (data) {
    offer = data.offer;
    pc.setRemoteDescription(new sessionDescription(data.offer), function () {
        pc.createAnswer(function (answer) {
            pc.setLocalDescription(new sessionDescription(answer), function () {
            socket.emit('make-answer', {
                answer: answer,
                to: data.socket
            });
            }, error);
        }, error);
    }, error);
});
socket.on('add-users', function (data) {
    var e = document.getElementById('users');
    var child = e.lastElementChild;  
    while (child) { 
        e.removeChild(child); 
        child = e.lastElementChild; 
    } 
    console.log(data);
    for(var i in data.users) {

            var el = document.createElement('div'),
            id = data.users[i].socketId;
            el.setAttribute('id', id);
            //el.setAttribute('class',"btn btn-info btn-lg");
            el.setAttribute('data-toggle',"modal");
            el.setAttribute('data-target',"#myModal");
            el.innerHTML = data.users[i].username;
            el.addEventListener('click', function () {
                createOffer(id);
            });
            document.getElementById('users').appendChild(el);
        
     }
    /*for (var i = 0; i< Object.keys(data.users).length; i++) {
        var el = document.createElement('div'),
        id = data.users[i].socketId;
        el.setAttribute('id', id);
        el.innerHTML = data.users[i].username;
        el.addEventListener('click', function () {
            createOffer(id);
        });
        document.getElementById('users').appendChild(el);
    }*/
});
socket.on('remove-user', function (id) {
    var div = document.getElementById(id);
    if(div !=null){
        document.getElementById('users').removeChild(div);
    }
});

$('.ext').click(function(){
    window.location.reload();

});
 