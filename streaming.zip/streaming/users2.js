var socket = io.connect('https://streamingkz.herokuapp.com'); //http://localhost:5000
var answersFrom = {}, offer;
var peerConnection = window.RTCPeerConnection ||  window.mozRTCPeerConnection || window.webkitRTCPeerConnection || window.msRTCPeerConnection;
var sessionDescription = window.RTCSessionDescription || window.mozRTCSessionDescription || window.webkitRTCSessionDescription || window.msRTCSessionDescription;
navigator.getUserMedia = (navigator.getUserMedia ||  navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia);
var pc = new peerConnection({ iceServers: 
    [{url:'stun:stun01.sipphone.com'},
{url:'stun:stun.ekiga.net'},
{url:'stun:stun.fwdnet.net'},
{url:'stun:stun.ideasip.com'},
{url:'stun:stun.iptel.org'},
{url:'stun:stun.rixtelecom.se'},
{url:'stun:stun.schlund.de'},
{url:'stun:stun.l.google.com:19302'},
{url:'stun:stun1.l.google.com:19302'},
{url:'stun:stun2.l.google.com:19302'},
{url:'stun:stun3.l.google.com:19302'},
{url:'stun:stun4.l.google.com:19302'},
{url:'stun:stunserver.org'},
{url:'stun:stun.softjoys.com'},
{url:'stun:stun.voiparound.com'},
{url:'stun:stun.voipbuster.com'},
{url:'stun:stun.voipstunt.com'},
{url:'stun:stun.voxgratia.org'},
{url:'stun:stun.xten.com'},
{
	url: 'turn:numb.viagenie.ca',
	credential: 'muazkh',
	username: 'webrtc@live.com'
},
{
	url: 'turn:192.158.29.39:3478?transport=udp',
	credential: 'JZEOEt2V3Qb0y27GRntt2u2PAYA=',
	username: '28224511:1379330808'
},
{
	url: 'turn:192.158.29.39:3478?transport=tcp',
	credential: 'JZEOEt2V3Qb0y27GRntt2u2PAYA=',
	username: '28224511:1379330808'
}]
});

/*--------------------------Screen recording------------------------------ */
let captureStream = null;
async function startCapture() {
    var displaymediastreamconstraints = {
        video: {
            displaySurface: 'monitor', // monitor, window, application, browser
            logicalSurface: true,
            cursor: 'always' // never, always, motion
        }
    };
   
    // above constraints are NOT supported YET
    // that's why overridnig them
    displaymediastreamconstraints = {
        video: true
    };
  
    try {
        if(navigator.mediaDevices.getDisplayMedia){
            captureStream = await navigator.mediaDevices.getDisplayMedia(displaymediastreamconstraints);

        }else{
            captureStream = await navigator.getDisplayMedia(displaymediastreamconstraints);
        }
    } catch(err) {
      console.error("Error: " + err);
    }
   // var videoScreen = document.getElementById('screen-video');       
 
     //   videoScreen.srcObject = captureStream;
       

  }

  startCapture();
  
   
 
/*console.log(screenStream);
var videoScreen = document.getElementById('screen-video');       
    if ("srcObject" in videoScreen) {
        videoScreen.srcObject = screenStream;
       
    } else {
        videoScreen.src = window.URL.createObjectURL(screenStream);
         
    }
*/
var name = "Halykov Roman Saidovich";
var id = 156548;
addUser(id,name);

/*------------------------------------------------ */
//navigator.getUserMedia({video: true}).then((stream)=> {video.srcObject = stream;  pc.addStream(stream);}, (err)=> console.error(err));
if(navigator.getUserMedia){
    navigator.getUserMedia({ video: true, audio: true }, loadCam, error);
}else{
    alert("UPPS cannot read UserMedia")
}
/*navigator.getUserMedia({video: true, audio:false}, function (stream) {
    var video = document.querySelector('video');
    video.srcObject = stream; //window.URL.createObjectURL(stream);
    pc.addStream(stream);
}, error);*/
//let mediaRecorder 
function loadCam(stream) {
 
    //var video = document.getElementById('user-video');       
    pc.addStream(captureStream);
    pc.addStream(stream);
  
    /*if ("srcObject" in video) {
        video.srcObject = stream;
    } else {
        video.src = window.URL.createObjectURL(stream);
    }*/
     
}
function error (err) {
    console.warn('Error', err);
    
}
function addUser(id,username){
    socket.emit('add-user', {
        userId:id,           
        username:username
    });
}
function createOffer (id) {
    pc.createOffer(function(offer) 
    {
        pc.setLocalDescription(new sessionDescription(offer), function ()
        {
            socket.emit('make-offer', {
            offer: offer,
            to: id,
            });
        }, error);
    }, error);
}

socket.on('send-stream',function (data){
    createOffer(data.socket);
});

socket.on('offer-made', function (data) {
    offer = data.offer;
    pc.setRemoteDescription(new sessionDescription(data.offer), function () {
        pc.createAnswer(function (answer) {
            pc.setLocalDescription(new sessionDescription(answer), function () {
            socket.emit('make-answer', {
                answer: answer,
                to: data.socket
            });
            }, error);
        }, error);
    }, error);
});

socket.on('answer-made', function (data) {
    pc.setRemoteDescription(new sessionDescription(data.answer),function () {
        if (!answersFrom[data.socket]) {
            createOffer(data.socket);
            answersFrom[data.socket] = true;
        }
    }, error);
});

 

